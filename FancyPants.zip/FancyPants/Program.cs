﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FancyPants
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> inputValues = null;
            List<string> outputValues = null;
            int inputValue;
            int valueA;
            int valueB;

            do
            {
                try
                {
                    Console.Clear();
                    inputValues = new List<int>();

                    //Reads positive value for Low.
                    inputValue = ReadPositiveIntegers(Enum.Type.Low);
                    inputValues.Add(inputValue);

                    //Reads positive value for High.
                    inputValue = ReadPositiveIntegers(Enum.Type.High);
                    inputValues.Add(inputValue);

                    //Reads positive value for A.
                    valueA = ReadPositiveIntegers(Enum.Type.A);
                    inputValues.Add(valueA);

                    //Reads positive value for B.
                    valueB = ReadPositiveIntegers(Enum.Type.B);
                    inputValues.Add(valueB);

                    Console.WriteLine("The numbers you entered are: " + string.Join(" ", inputValues));
                    Console.ReadLine();

                    outputValues = new List<string>();
                    outputValues = ProcessInputs(inputValues, valueA, valueB, outputValues);

                    Console.WriteLine("Your output : " + string.Join(" ", outputValues));
                }
                catch (DivideByZeroException e)
                {
                    Console.WriteLine(string.Format("Exception : {0}", e.Message));
                }
                catch (Exception e)
                {
                    Console.WriteLine(string.Format("Exception : {0}", e.Message));
                }

                Console.WriteLine("\nDo you want to continue (Y/N)? ");

            } while (Console.ReadKey().KeyChar != 'Y');

        }

        #region Private Methods

        /// <summary>
        /// Get the paositive integer based on the type passing.
        /// </summary>
        /// <param name="type"></param>
        /// <returns>positive number</returns>
        private static int ReadPositiveIntegers(Enum.Type type)
        {
            Regex regex = new Regex(@"^[0-9]{1,6}$");
            string input = "";
            do
            {
                Console.WriteLine("Enter positive number for " + type.ToString());
                input = Console.ReadLine();

            }
            while (!regex.IsMatch(input));
            return int.Parse(input);
        }

        /// <summary>
        /// To process the input values and returns output values.
        /// </summary>
        /// <param name="inputValues"></param>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <param name="outputValues"></param>
        /// <returns>outputValues</returns>
        private static List<string> ProcessInputs(List<int> inputValues, int a, int b, List<string> outputValues)
        {
            try
            {
                foreach (int value in inputValues)
                {
                    if (value % a == 0 && value % b == 0)
                    {
                        outputValues.Add("FancyPants");
                    }
                    else if (value % b == 0)
                    {
                        outputValues.Add("Pants");
                    }
                    else if (value % a == 0)
                    {
                        outputValues.Add("Fancy");
                    }
                    else
                    {
                        outputValues.Add(value.ToString());
                    }
                }
            }
            catch (DivideByZeroException e)
            {
                throw new DivideByZeroException(e.Message);
            }
            return outputValues;
        }
        #endregion

    }
}

